package geometries;

import primitives.Point;

/**
 * class Triangle represents two-dimensional triangle in 3D space
 */
public class Triangle extends Polygon {
	/**
	 * constructor using at father constructor
	 * 
	 * @param point1
	 * @param point2
	 * @param point3
	 */
	public Triangle(Point point1, Point point2, Point point3) {
		super(point1, point2, point3);
	}
}